function Account(owner, balance) {
    this.owner = owner;
    this.balance = balance;

    this.deposit = function(amount) {
        this.balance += amount;
    };

    this.withdraw = function(amount) {
        this.balance -= amount;
    };

    this.getBalance = function() {
        return this.balance;
    };
}

// 객체 생성 및 테스트
let account1 = new Account("John", 1000000);

console.log(account1.owner);
console.log(account1.getBalance());

account1.withdraw(100000);
console.log(account1.getBalance());

account1.deposit(500000);
console.log(account1.getBalance());