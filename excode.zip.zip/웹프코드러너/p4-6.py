function isPrime(n) {
  if (n < 2) return false;
  for (let i = 2; i <= Math.sqrt(n); i++) {
    if (n % i === 0) return false;
  }
  return true;
}

for (let n = 1; n <= 100; n++) {
  if (isPrime(n)) {
    console.log(`${n}은 소수입니다`);
  }
}
