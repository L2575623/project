console.log(15 - 5 * (7 + 2 * 3) ** 2);
console.log(5 * (2 + (5 - 3) / 4) * 128);
console.log((3 - 2) ** 5 + 2);

const x = Number(prompt("x의 값을 입력하세요:"));
const y = Number(prompt("y의 값을 입력하세요:"));

const result1 = x ** 2 * y + Math.log2(x);
const result2 = x * Math.sqrt(2 - 2 * Math.sin(y));

console.log("첫 번째 결과:", result1);
console.log("두 번째 결과:", result2);