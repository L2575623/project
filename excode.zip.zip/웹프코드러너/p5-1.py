function max(n1, n2)
{
  if (n1 > n2)
    {
      return n1;
    } 
    else
      {
        return n2;
      }
}

console.log(max(2, 5));

console.log('--------------------');

function facto(n)
{
    if (n === 0 || n === 1)
      {
        return 1;
      }  
    let result = 1;
    for (let i = 2; i <= n; i++)
      {
        result *= i;
      }
    return result;
}

console.log(facto(5));

console.log('--------------------');

function pibo(n)
{
  if (n <= 1)
    {
      return n;
    }
  return pibo(n - 1) + pibo(n - 2);
}
console.log(pibo(6));

console.log('--------------------');

function calc(n1, n2, operator)
{
  if (operator === "+")
    {
      return n1 + n2;
    }
    else if (operator === "-")
      {
        return n1 - n2;
      }
      else if (operator === "*")
        {
          return n1 * n2;
        }
        else if (operator === "/")
          {
            return n1 / n2;
          }
          else
            {
              return "Invalid operator";
            }
}
console.log(calc(3, 5, "+"));
console.log(calc(8, 2, "/"));

