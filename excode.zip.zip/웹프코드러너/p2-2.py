console.log(10 > 5);
console.log(10 === "10");
console.log(10 == "10");
console.log(5 >= 5);
console.log(3 != "3");
console.log(3 !== "3");
console.log(10 > 5 && 3 < 2);
console.log(10 > 5 || 3 < 2);

