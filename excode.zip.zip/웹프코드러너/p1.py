// 우주선 정보
const spaceshipName = "Hope";
const speedMph = 17500;
const milesPerKm = 0.621;
const distanceMarsKm = 225000000;
const distanceMoonKm = 384400;
const spaceshipWeight = 5500;
const fuelWeight = 1100;

const distanceMarsMiles = distanceMarsKm * milesPerKm;
const distanceMoonMiles = distanceMoonKm * milesPerKm;

const timeMarsHours = distanceMarsMiles / speedMph;
const timeMoonHours = distanceMoonMiles / speedMph;

const launchWeight = spaceshipWeight + fuelWeight;

console.log(`우주선 ${spaceshipName}는 화성까지 ${timeMarsHours.toFixed(0)}시간 걸립니다`);
console.log(`우주선 ${spaceshipName}는 달까지 ${timeMoonHours.toFixed(0)}시간 걸립니다`);
console.log(`우주선 ${spaceshipName}의 발사무게는 ${launchWeight}kg 입니다`);
