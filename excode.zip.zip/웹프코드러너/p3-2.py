const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("년도를 입력하세요: ", (input) => {
    const year = Number(input);

    if (year % 400 === 0) {
        console.log(year + "년은 윤년입니다");
    } else if (year % 100 === 0) {
        console.log(year + "년은 평년입니다");
    } else if (year % 4 === 0) {
        console.log(year + "년은 윤년입니다");
    } else {
        console.log(year + "년은 평년입니다");
    }

    rl.close();
});
