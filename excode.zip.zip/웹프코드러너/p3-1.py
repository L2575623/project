const n = Number(prompt("정수 n을 입력하세요."));

if (n % 2 === 0) {
    console.log(n + "은 짝수입니다");
} else {
    console.log(n + "은 홀수입니다");
}