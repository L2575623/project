let dan = Number(prompt("1부터 9 사이의 숫자를 입력하세요."));

if (dan >= 1 && dan <= 9 && Number.isInteger(dan)) {
    console.log("구구단 " + dan + "단");

    for (let i = 1; i <= 9; i++) {
        console.log(dan + " x " + i + " = " + (dan * i));
    }
} else {
    console.log("1부터 9 사이의 정수를 입력하세요.");
}
