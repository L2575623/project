function Calculator()
{
    
}
// constructor function test
let calculator = new Calculator();
calculator.read(1, 2);
console.log( "Sum=" + calculator.sum() );
console.log( "Mul=" + calculator.mul() );