console.log(true || false && false);  // true
console.log((true || false) && false);  // false
console.log(!(true || false) && true);  // false
console.log("" || "JavaScript");  // JavaScript

const a = 0;
const b = 10;
console.log((a || b) && 20);  // 20

const a = "";
const b = "Hello";
const c = "World";
console.log(a || b && c);  // World

const x = 10;
const y = 20;
const z = 30;
console.log(x && y && z);  // 30

const x = 0;
const y = 10;
const z = 20;
console.log(x || y || z);  // 10

const x = 10;
const y = 20;
console.log( !(x > 5 && y < 10) || (x === 10 && y === 20) );  // true

const x = 10;
console.log(x > 5 && 0 || x < 5);  // 0